class Gradebook < ApplicationRecord
    belongs_to :student
end
