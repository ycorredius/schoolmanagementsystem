module SchoolHelper
end
